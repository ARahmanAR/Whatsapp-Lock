export interface LiveLocation {
  id: string;
  lat: number;
  lng: number;
  speed: number;
  lastUpdated: number;
  accuracy: number;
  degrees: any;
}
