export interface ContactStatus {
  id: string;
  status: string;
  stale?: boolean;
}
