export interface ScrapQrcode {
  base64Image: string;
  urlCode: string;
}
