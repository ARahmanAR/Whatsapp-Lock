export enum ChatState {
  Typing = 0,
  Recording = 1,
  Paused = 2
}
